const dataBase = require('../util/database').getDB;
const ObjectId = require('mongodb').ObjectId;

 exports.savePrd = function(prd){   
     dataBase().collection('prdPractice').insertOne(prd).then().catch(er=>console.log(er));
 }

 exports.allPrd = function(){
     return dataBase().collection('prdPractice').find().toArray();
 }

 exports.getById = function(pid){
    return dataBase().collection('prdPractice').findOne({'_id': new ObjectId(pid)});
 }

 exports.editPrd = function(prdId,prd){   
    dataBase().collection('prdPractice').updateOne({ '_id': new ObjectId(prdId) }, { $set: prd })
    .then().catch(er=>console.log(er));
 }

 exports.deleteById = function(prdId){
   return dataBase().collection('prdPractice').deleteOne({ '_id': new ObjectId(prdId) });
 }