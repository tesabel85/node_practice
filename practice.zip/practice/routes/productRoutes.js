const express = require('express');
const PrdController = require('../controller/productController');


const routes = express.Router();

routes.get('/savePrd',PrdController.getPrdForm);
routes.post('/savePrd',PrdController.postPrd);

routes.get('/allPrd', PrdController.allPrd);

routes.get('/editPrd/:prdId', PrdController.getPrdEditForm);
routes.post('/editPrd', PrdController.postPrdEditForm);

routes.post('/deletePrd', PrdController.deleteProduct);

module.exports = routes;