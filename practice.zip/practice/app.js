const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const expressValidator = require("express-validator");
const expressSession = require('express-session');
const mongoConnection = require('./util/database').mongoConnection;
const PrdRoute = require('./routes/productRoutes');

const app = express();

app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({limit: '10mb', extended: true}));

app.use(expressValidator());
app.use(expressSession({ secret:'max', saveUninitialized:false, resave:false }));

app.use(PrdRoute);

app.get("/",(req,res)=>{
    res.send("done!! ");
});

app.listen(8080,function(){
    mongoConnection();
    console.log("server is star!! ");
});