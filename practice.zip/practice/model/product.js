
module.exports = class Product{
    constructor(name,type,price,description,imageUrl){
        this.name = name;
        this.type = type;
        this.image = imageUrl;
        this.price = price;
        this.description = description;
    }
}