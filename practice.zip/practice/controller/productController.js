const PrdRepository = require('../repository/productRepository');
const Product = require('../model/product');
const PrdService = require('../service/PrdService');

// save PRD
exports.getPrdForm = (req,res,next)=>{
    res.render('addProduct',{ title:"Form validation", success:req.session.success, errors:req.session.errors });
    req.session.errors = null;
}
exports.postPrd = (req,res,next)=>{
     if(PrdService.checkPrdSaveValidation(req)){
        PrdRepository.savePrd( new Product(req.body.name, req.body.type, req.body.price, req.body.description, PrdService.convertToBase64(req.body.image)));
     }   
    res.redirect('/savePrd');
}

//  all PRDs  
exports.allPrd = (req,res,next)=>{
    PrdRepository.allPrd().then(arr => {
        let prdArr = PrdService.converterToImage(arr);
        res.render('prdsPage',{ 'prds' : prdArr});    
    }).catch(e=>console.log(e));
      PrdService.clearFolder();
}

//edit Prd
exports.getPrdEditForm = (req,res,next)=>{
     PrdRepository.getById(req.params.prdId).then(rv=>res.render('editProduct',{ 'prdKey' : rv})).catch(e=>console.log(e)); 
}
exports.postPrdEditForm = (req,res,next)=>{
    PrdRepository.editPrd(req.body._id,new Product(req.body.name, req.body.type, req.body.price, req.body.description, req.body.image));
    res.redirect('/allPrd');
}

//delete Prd
exports.deleteProduct = (req,res,next)=>{
    PrdRepository.deleteById(req.body.prdId);
    res.redirect('/allPrd');
}

