const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;
let DB;

function mongoConnection(){
    MongoClient.connect('mongodb://localhost:27017',{ useUnifiedTopology : true })
    .then(client => {
         DB = client.db('onlineShopping');
        // console.log("db is connected successfuly. ")
    })
    .catch(err => console.log(err));
}

function getDB(){
    if(DB){
        return DB;
    }
    throw new Error('our DB is down :) ');
}

exports.mongoConnection = mongoConnection;
exports.getDB = getDB;